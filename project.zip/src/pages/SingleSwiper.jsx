import React, { useEffect } from 'react'
import { useParams } from "react-router-dom";

const SingleSwiper = () => {
  const { id } = useParams();

  return (
    <div>
      
    </div>
  )
}

export default SingleSwiper
